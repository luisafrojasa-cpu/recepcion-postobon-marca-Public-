"""
API de integración y reportes - Recepción de materias primas (prototipo)
Proyecto: Digitalización de Recepción de Materias Primas con QR/RFID

Cubre de forma inicial:
  RF01  Autenticación y control de acceso por rol (tokens)
  RF03  Validación de fecha de vencimiento
  RF04  Tolerancia de peso contra la orden de compra (±1 %)
  RF05  Integración con ERP (simulada: actualiza el stock y el estado del lote)
  RF10  Reportes y KPIs, con exportación a CSV

Usa solo la librería estándar de Python 3.9+: no hay que instalar nada.
Ejecutar:  python api_postobon.py --puerto 8000
"""
import argparse
import csv
import hashlib
import io
import json
import re
import secrets
import sqlite3
import threading
import time
from datetime import date, datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

TOLERANCIA_PCT = 1.0      # tolerancia de peso permitida (RF04)
TOKEN_SEGUNDOS = 8 * 3600 # duración del token (un turno)

# Catálogo de lotes de prueba. "dias" = días que faltan para vencer desde hoy.
LOTES = {
    "QR-AZU-0001": {"insumo": "Azúcar refinada", "proveedor": "Ingenio del Valle S.A.", "lote": "L-AZU-2411", "oc": 25000, "min_vida": 90, "dias": 240},
    "QR-PUL-0002": {"insumo": "Pulpa de mango", "proveedor": "Agrofruta S.A.S.", "lote": "L-MAN-0932", "oc": 4000, "min_vida": 30, "dias": 45},
    "QR-PET-0003": {"insumo": "Preforma PET", "proveedor": "Plastipol Ltda.", "lote": "L-PET-7781", "oc": 12000, "min_vida": 180, "dias": 720},
    "QR-PUL-0004": {"insumo": "Pulpa de lulo", "proveedor": "Agrofruta S.A.S.", "lote": "L-LUL-0517", "oc": 2500, "min_vida": 30, "dias": 10},
    "QR-AZU-0005": {"insumo": "Azúcar refinada", "proveedor": "Ingenio del Valle S.A.", "lote": "L-AZU-2399", "oc": 18000, "min_vida": 90, "dias": -5},
    "RFID-E200-0006": {"insumo": "Pulpa de maracuyá", "proveedor": "Frutas del Trópico S.A.S.", "lote": "L-MAR-0210", "oc": 3000, "min_vida": 30, "dias": 90},
}

ROLES_RECEPCION = {"operario", "jefe", "admin"}
ROLES_REPORTES = {"jefe", "auditor", "admin"}


# ----------------------------------------------------------------- lógica de negocio
def evaluar_vencimiento(lote):
    """RF03 + RF07: aprueba o bloquea según la vida útil mínima y asigna semáforo."""
    dias, minimo = lote["dias"], lote["min_vida"]
    if dias < 0:
        return {"ok": False, "dias": dias, "semaforo": "rojo", "motivo": f"Lote vencido hace {-dias} días"}
    if dias < minimo:
        return {"ok": False, "dias": dias, "semaforo": "rojo",
                "motivo": f"Quedan {dias} días y se exigen mínimo {minimo}"}
    semaforo = "amarillo" if dias <= minimo * 1.5 else "verde"
    return {"ok": True, "dias": dias, "semaforo": semaforo, "motivo": ""}


def evaluar_peso(peso, oc):
    """RF04: diferencia porcentual contra la orden de compra."""
    dif = (peso - oc) / oc * 100
    return {"ok": abs(dif) <= TOLERANCIA_PCT + 1e-9, "dif_pct": round(dif, 2)}


def _hash(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 100_000).hex()


# ----------------------------------------------------------------- base de datos
class Almacen:
    """SQLite con un candado para uso desde varios hilos del servidor."""

    def __init__(self, ruta=":memory:"):
        self.db = sqlite3.connect(ruta, check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.Lock()
        self.tokens = {}
        self.db.executescript("""
            CREATE TABLE IF NOT EXISTS usuarios(usuario TEXT PRIMARY KEY, nombre TEXT, rol TEXT, sal TEXT, clave TEXT);
            CREATE TABLE IF NOT EXISTS recepciones(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT, codigo TEXT, lote TEXT, insumo TEXT, proveedor TEXT,
                oc REAL, peso REAL, dif_pct REAL, dias INTEGER, estado TEXT, motivo TEXT, semaforo TEXT,
                operario TEXT, segundos REAL);
            CREATE TABLE IF NOT EXISTS stock_erp(insumo TEXT PRIMARY KEY, kg REAL);
            CREATE TABLE IF NOT EXISTS estado_lote(lote TEXT PRIMARY KEY, estado TEXT);
        """)

    def crear_usuario(self, usuario, nombre, rol, clave):
        sal = secrets.token_hex(16)
        with self.lock:
            self.db.execute("INSERT INTO usuarios VALUES (?,?,?,?,?)", (usuario, nombre, rol, sal, _hash(clave, sal)))
            self.db.commit()

    def login(self, usuario, clave):
        with self.lock:
            f = self.db.execute("SELECT * FROM usuarios WHERE usuario=?", (usuario,)).fetchone()
        if not f or not secrets.compare_digest(f["clave"], _hash(clave, f["sal"])):
            return None
        token = secrets.token_urlsafe(24)
        self.tokens[token] = {"usuario": f["usuario"], "rol": f["rol"], "vence": time.time() + TOKEN_SEGUNDOS}
        return {"token": token, "usuario": f["usuario"], "nombre": f["nombre"], "rol": f["rol"]}

    def sesion(self, token):
        s = self.tokens.get(token)
        if s and s["vence"] > time.time():
            return s
        self.tokens.pop(token, None)
        return None

    def registrar(self, operario, codigo, peso, segundos=None):
        """Devuelve (código HTTP, cuerpo). Guarda cada intento para auditoría."""
        lote = LOTES.get(codigo)
        if not lote:
            return 404, {"error": "Código no registrado en el sistema", "codigo": codigo}
        with self.lock:
            ya = self.db.execute("SELECT 1 FROM recepciones WHERE codigo=? AND estado='Aprobado'", (codigo,)).fetchone()
            if ya:
                return 409, {"error": "El lote ya fue aprobado antes", "lote": lote["lote"]}
            v = evaluar_vencimiento(lote)
            p = evaluar_peso(peso, lote["oc"]) if peso is not None else None
            if not v["ok"]:
                estado, motivo, sem = "Rechazado", v["motivo"], "rojo"
            elif p is None or not p["ok"]:
                estado, sem = "Novedad de peso", v["semaforo"]
                motivo = "Falta el peso" if p is None else f"Diferencia de {p['dif_pct']} % supera ±{TOLERANCIA_PCT} %"
            else:
                estado, motivo, sem = "Aprobado", "", v["semaforo"]
            self.db.execute(
                "INSERT INTO recepciones(ts,codigo,lote,insumo,proveedor,oc,peso,dif_pct,dias,estado,motivo,semaforo,operario,segundos)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (datetime.now().isoformat(timespec="seconds"), codigo, lote["lote"], lote["insumo"], lote["proveedor"],
                 lote["oc"], peso, p["dif_pct"] if p else None, v["dias"], estado, motivo, sem, operario, segundos))
            cuerpo = {"estado": estado, "lote": lote["lote"], "insumo": lote["insumo"], "semaforo": sem,
                      "dias_para_vencer": v["dias"], "dif_pct": p["dif_pct"] if p else None, "motivo": motivo}
            if estado == "Aprobado":  # RF05: el ERP (simulado) actualiza stock y estado
                self.db.execute("INSERT INTO stock_erp VALUES (?,?) ON CONFLICT(insumo) DO UPDATE SET kg=kg+excluded.kg",
                                (lote["insumo"], peso))
                self.db.execute("INSERT OR REPLACE INTO estado_lote VALUES (?,?)", (lote["lote"], "Disponible para Planta"))
                cuerpo["erp"] = {"sincronizado": True, "estado_lote": "Disponible para Planta"}
            self.db.commit()
        return (201 if estado == "Aprobado" else 422), cuerpo

    def stock(self):
        with self.lock:
            return {f["insumo"]: f["kg"] for f in self.db.execute("SELECT * FROM stock_erp ORDER BY insumo")}

    def _filtrar(self, desde, hasta, proveedor=None):
        sql, args = "SELECT * FROM recepciones WHERE 1=1", []
        if desde:
            sql += " AND date(ts) >= ?"; args.append(desde)
        if hasta:
            sql += " AND date(ts) <= ?"; args.append(hasta)
        if proveedor:
            sql += " AND proveedor = ?"; args.append(proveedor)
        with self.lock:
            return self.db.execute(sql + " ORDER BY id", args).fetchall()

    def kpis(self, desde=None, hasta=None, proveedor=None):
        filas = self._filtrar(desde, hasta, proveedor)
        total = len(filas)
        cuenta = lambda e: sum(1 for f in filas if f["estado"] == e)
        tiempos = [f["segundos"] for f in filas if f["segundos"] is not None]
        return {
            "total_recepciones": total,
            "aprobadas": cuenta("Aprobado"),
            "rechazadas": cuenta("Rechazado"),
            "novedades_peso": cuenta("Novedad de peso"),
            "pct_rechazados": round(cuenta("Rechazado") / total * 100, 1) if total else 0.0,
            "tiempo_promedio_seg": round(sum(tiempos) / len(tiempos), 1) if tiempos else None,
            "kg_recibidos": round(sum(f["peso"] or 0 for f in filas if f["estado"] == "Aprobado"), 2),
        }

    def csv(self, desde=None, hasta=None, proveedor=None):
        filas = self._filtrar(desde, hasta, proveedor)
        sal = io.StringIO()
        w = csv.writer(sal)
        w.writerow(["ts", "codigo", "lote", "insumo", "proveedor", "oc_kg", "peso_kg", "dif_pct", "estado", "motivo", "semaforo", "operario"])
        for f in filas:
            w.writerow([f["ts"], f["codigo"], f["lote"], f["insumo"], f["proveedor"], f["oc"], f["peso"], f["dif_pct"],
                        f["estado"], f["motivo"], f["semaforo"], f["operario"]])
        return sal.getvalue()


def sembrar(almacen):
    for u, n, r, c in [("operario1", "Operario de prueba", "operario", "Operario#1"),
                       ("jefe1", "Jefe de bodega de prueba", "jefe", "Jefe#2026"),
                       ("auditor1", "Auditor de prueba", "auditor", "Audit#2026"),
                       ("admin", "Administrador", "admin", "Admin#2026")]:
        almacen.crear_usuario(u, n, r, c)


# ----------------------------------------------------------------- servidor HTTP
def crear_servidor(almacen, puerto=0):
    class Manejador(BaseHTTPRequestHandler):
        def log_message(self, *a):  # silencia el log por defecto
            pass

        def _enviar(self, codigo, cuerpo, tipo="application/json"):
            datos = (cuerpo if isinstance(cuerpo, str) else json.dumps(cuerpo, ensure_ascii=False)).encode("utf-8")
            self.send_response(codigo)
            self.send_header("Content-Type", f"{tipo}; charset=utf-8")
            self.send_header("Content-Length", str(len(datos)))
            self.end_headers()
            self.wfile.write(datos)

        def _sesion(self):
            m = re.match(r"Bearer (.+)", self.headers.get("Authorization", ""))
            return almacen.sesion(m.group(1)) if m else None

        def _json(self):
            try:
                return json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
            except (ValueError, json.JSONDecodeError):
                return None

        def do_POST(self):
            ruta = urlparse(self.path).path
            cuerpo = self._json()
            if cuerpo is None:
                return self._enviar(400, {"error": "El cuerpo debe ser JSON válido"})
            if ruta == "/api/login":
                r = almacen.login(str(cuerpo.get("usuario", "")).lower(), str(cuerpo.get("clave", "")))
                return self._enviar(200, r) if r else self._enviar(401, {"error": "Usuario o contraseña incorrectos"})
            s = self._sesion()
            if not s:
                return self._enviar(401, {"error": "Falta iniciar sesión o el token venció"})
            if ruta == "/api/recepciones":
                if s["rol"] not in ROLES_RECEPCION:
                    return self._enviar(403, {"error": "Tu rol no puede registrar recepciones"})
                peso = cuerpo.get("peso")
                if peso is not None and (not isinstance(peso, (int, float)) or peso <= 0):
                    return self._enviar(400, {"error": "El peso debe ser un número mayor que cero"})
                codigo = str(cuerpo.get("codigo", "")).strip().upper()
                codigo_http, r = almacen.registrar(s["usuario"], codigo, peso, cuerpo.get("segundos"))
                return self._enviar(codigo_http, r)
            self._enviar(404, {"error": "Ruta no encontrada"})

        def do_GET(self):
            u = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            s = self._sesion()
            if u.path == "/api/salud":
                return self._enviar(200, {"estado": "ok"})
            if not s:
                return self._enviar(401, {"error": "Falta iniciar sesión o el token venció"})
            m = re.fullmatch(r"/api/lotes/([\w-]+)", u.path)
            if m:
                lote = LOTES.get(m.group(1).upper())
                if not lote:
                    return self._enviar(404, {"error": "Código no registrado en el sistema"})
                return self._enviar(200, {**lote, "vencimiento": evaluar_vencimiento(lote)})
            if u.path == "/api/erp/stock":
                return self._enviar(200, almacen.stock())
            if u.path in ("/api/reportes/kpis", "/api/reportes/export.csv"):
                if s["rol"] not in ROLES_REPORTES:
                    return self._enviar(403, {"error": "Tu rol no puede ver reportes"})
                f = (q.get("desde"), q.get("hasta"), q.get("proveedor"))
                if u.path.endswith("kpis"):
                    return self._enviar(200, almacen.kpis(*f))
                return self._enviar(200, almacen.csv(*f), "text/csv")
            self._enviar(404, {"error": "Ruta no encontrada"})

    return ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="API de recepción de materias primas")
    ap.add_argument("--puerto", type=int, default=8000)
    ap.add_argument("--db", default="postobon.db", help="archivo SQLite (por defecto postobon.db)")
    a = ap.parse_args()
    alm = Almacen(a.db)
    if not alm.db.execute("SELECT 1 FROM usuarios").fetchone():
        sembrar(alm)
    srv = crear_servidor(alm, a.puerto)
    print(f"API lista en http://127.0.0.1:{srv.server_address[1]}  (Ctrl+C para detener)")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
