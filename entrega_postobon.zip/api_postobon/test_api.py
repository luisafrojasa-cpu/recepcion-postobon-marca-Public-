"""Pruebas de la API. Ejecutar:  python -m unittest test_api -v"""
import json
import threading
import unittest
import urllib.error
import urllib.request

import api_postobon as api


class PruebasLogica(unittest.TestCase):
    """Reglas de negocio sin servidor."""

    def test_rf03_lote_vigente_aprobado(self):
        v = api.evaluar_vencimiento(api.LOTES["QR-AZU-0001"])
        self.assertTrue(v["ok"]); self.assertEqual(v["semaforo"], "verde")

    def test_rf03_lote_vencido_bloqueado(self):
        v = api.evaluar_vencimiento(api.LOTES["QR-AZU-0005"])
        self.assertFalse(v["ok"]); self.assertIn("vencido", v["motivo"])

    def test_rf03_bajo_vida_util_minima_bloqueado(self):
        self.assertFalse(api.evaluar_vencimiento(api.LOTES["QR-PUL-0004"])["ok"])

    def test_rf07_semaforo_amarillo(self):
        self.assertEqual(api.evaluar_vencimiento(api.LOTES["QR-PUL-0002"])["semaforo"], "amarillo")

    def test_rf04_tolerancia_en_el_borde(self):
        self.assertTrue(api.evaluar_peso(25250, 25000)["ok"])    # +1,00 %
        self.assertFalse(api.evaluar_peso(25251, 25000)["ok"])   # +1,004 %
        self.assertFalse(api.evaluar_peso(24700, 25000)["ok"])   # -1,2 %


class PruebasAPI(unittest.TestCase):
    """Extremo a extremo con un servidor real en un puerto libre."""

    def setUp(self):
        self.alm = api.Almacen(":memory:")
        api.sembrar(self.alm)
        self.srv = api.crear_servidor(self.alm, 0)
        self.base = f"http://127.0.0.1:{self.srv.server_address[1]}"
        threading.Thread(target=self.srv.serve_forever, daemon=True).start()

    def tearDown(self):
        self.srv.shutdown(); self.srv.server_close()

    def llamar(self, metodo, ruta, datos=None, token=None):
        req = urllib.request.Request(self.base + ruta, method=metodo,
                                     data=json.dumps(datos).encode() if datos is not None else None)
        req.add_header("Content-Type", "application/json")
        if token:
            req.add_header("Authorization", f"Bearer {token}")
        try:
            with urllib.request.urlopen(req) as r:
                return r.status, r.read().decode()
        except urllib.error.HTTPError as e:
            return e.code, e.read().decode()

    def entrar(self, usuario, clave):
        c, cuerpo = self.llamar("POST", "/api/login", {"usuario": usuario, "clave": clave})
        return json.loads(cuerpo)["token"] if c == 200 else None

    def recibir(self, token, codigo, peso, seg=None):
        c, cuerpo = self.llamar("POST", "/api/recepciones", {"codigo": codigo, "peso": peso, "segundos": seg}, token)
        return c, json.loads(cuerpo)

    # ---- RF01
    def test_rf01_login_valido(self):
        self.assertIsNotNone(self.entrar("operario1", "Operario#1"))

    def test_rf01_login_invalido(self):
        c, _ = self.llamar("POST", "/api/login", {"usuario": "operario1", "clave": "mala"})
        self.assertEqual(c, 401)

    def test_rf01_sin_token_no_entra(self):
        self.assertEqual(self.llamar("GET", "/api/lotes/QR-AZU-0001")[0], 401)

    def test_rf01_rol_auditor_no_registra(self):
        t = self.entrar("auditor1", "Audit#2026")
        self.assertEqual(self.recibir(t, "QR-AZU-0001", 25000)[0], 403)

    def test_rf01_rol_operario_no_ve_reportes(self):
        t = self.entrar("operario1", "Operario#1")
        self.assertEqual(self.llamar("GET", "/api/reportes/kpis", token=t)[0], 403)

    # ---- RF02
    def test_rf02_codigo_no_registrado(self):
        t = self.entrar("operario1", "Operario#1")
        self.assertEqual(self.recibir(t, "QR-FALSO-9999", 100)[0], 404)

    def test_rf02_ficha_del_lote(self):
        t = self.entrar("operario1", "Operario#1")
        c, cuerpo = self.llamar("GET", "/api/lotes/QR-PET-0003", token=t)
        self.assertEqual(c, 200); self.assertEqual(json.loads(cuerpo)["insumo"], "Preforma PET")

    # ---- RF03 / RF04 / RF05
    def test_aprobar_actualiza_erp(self):
        t = self.entrar("operario1", "Operario#1")
        c, r = self.recibir(t, "QR-AZU-0001", 25100)
        self.assertEqual(c, 201); self.assertEqual(r["estado"], "Aprobado")
        self.assertEqual(r["erp"]["estado_lote"], "Disponible para Planta")
        _, stock = self.llamar("GET", "/api/erp/stock", token=t)
        self.assertEqual(json.loads(stock)["Azúcar refinada"], 25100)

    def test_rf03_vencido_se_rechaza_y_no_toca_el_erp(self):
        t = self.entrar("operario1", "Operario#1")
        c, r = self.recibir(t, "QR-AZU-0005", 18000)
        self.assertEqual((c, r["estado"]), (422, "Rechazado"))
        self.assertEqual(json.loads(self.llamar("GET", "/api/erp/stock", token=t)[1]), {})

    def test_rf04_peso_fuera_de_tolerancia(self):
        t = self.entrar("operario1", "Operario#1")
        c, r = self.recibir(t, "QR-AZU-0001", 24000)  # -4 %
        self.assertEqual((c, r["estado"], r["dif_pct"]), (422, "Novedad de peso", -4.0))

    def test_lote_duplicado(self):
        t = self.entrar("operario1", "Operario#1")
        self.recibir(t, "QR-PET-0003", 12000)
        self.assertEqual(self.recibir(t, "QR-PET-0003", 12000)[0], 409)

    def test_peso_invalido(self):
        t = self.entrar("operario1", "Operario#1")
        self.assertEqual(self.llamar("POST", "/api/recepciones", {"codigo": "QR-PET-0003", "peso": -5}, t)[0], 400)

    # ---- RF10
    def test_rf10_kpis_y_csv(self):
        t = self.entrar("operario1", "Operario#1")
        self.recibir(t, "QR-AZU-0001", 25000, 40)      # aprobado
        self.recibir(t, "QR-PET-0003", 12000, 20)      # aprobado
        self.recibir(t, "QR-AZU-0005", 18000, 30)      # rechazado (vencido)
        self.recibir(t, "QR-PUL-0002", 3500, 10)       # novedad de peso
        j = self.entrar("jefe1", "Jefe#2026")
        _, cuerpo = self.llamar("GET", "/api/reportes/kpis", token=j)
        k = json.loads(cuerpo)
        self.assertEqual((k["total_recepciones"], k["aprobadas"], k["rechazadas"], k["novedades_peso"]), (4, 2, 1, 1))
        self.assertEqual(k["pct_rechazados"], 25.0)
        self.assertEqual(k["tiempo_promedio_seg"], 25.0)
        self.assertEqual(k["kg_recibidos"], 37000)
        c, csv_txt = self.llamar("GET", "/api/reportes/export.csv", token=j)
        self.assertEqual(c, 200); self.assertEqual(len(csv_txt.strip().splitlines()), 5)  # encabezado + 4 filas

    def test_rf10_filtro_por_proveedor(self):
        t = self.entrar("operario1", "Operario#1")
        self.recibir(t, "QR-AZU-0001", 25000); self.recibir(t, "QR-PUL-0002", 4000)
        j = self.entrar("jefe1", "Jefe#2026")
        _, cuerpo = self.llamar("GET", "/api/reportes/kpis?proveedor=Agrofruta%20S.A.S.", token=j)
        self.assertEqual(json.loads(cuerpo)["total_recepciones"], 1)


if __name__ == "__main__":
    unittest.main()
