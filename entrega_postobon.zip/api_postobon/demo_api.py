"""Demostración: levanta la API y hace peticiones reales. Ejecutar: python demo_api.py"""
import json, threading, urllib.request, urllib.error
import api_postobon as api

alm = api.Almacen(":memory:"); api.sembrar(alm)
srv = api.crear_servidor(alm, 0)
base = f"http://127.0.0.1:{srv.server_address[1]}"
threading.Thread(target=srv.serve_forever, daemon=True).start()

def pedir(metodo, ruta, datos=None, token=None):
    r = urllib.request.Request(base + ruta, method=metodo, data=json.dumps(datos).encode() if datos is not None else None)
    r.add_header("Content-Type", "application/json")
    if token: r.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(r) as x: return x.status, x.read().decode()
    except urllib.error.HTTPError as e: return e.code, e.read().decode()

def mostrar(titulo, resp):
    print(f"\n### {titulo}\nHTTP {resp[0]}\n{resp[1].strip()[:600]}")

mostrar("1. Login con clave incorrecta", pedir("POST", "/api/login", {"usuario": "operario1", "clave": "mala"}))
c, cuerpo = pedir("POST", "/api/login", {"usuario": "operario1", "clave": "Operario#1"})
op = json.loads(cuerpo)["token"]; print(f"\n### 2. Login correcto\nHTTP {c}\nrol: {json.loads(cuerpo)['rol']}")
mostrar("3. Recepción de lote vigente (azúcar, 25.100 kg)", pedir("POST", "/api/recepciones", {"codigo": "QR-AZU-0001", "peso": 25100, "segundos": 38}, op))
mostrar("4. Lote vencido", pedir("POST", "/api/recepciones", {"codigo": "QR-AZU-0005", "peso": 18000, "segundos": 22}, op))
mostrar("5. Peso fuera de tolerancia (-4 %)", pedir("POST", "/api/recepciones", {"codigo": "QR-PUL-0002", "peso": 3840, "segundos": 51}, op))
mostrar("6. Stock en el ERP simulado", pedir("GET", "/api/erp/stock", token=op))
jf = json.loads(pedir("POST", "/api/login", {"usuario": "jefe1", "clave": "Jefe#2026"})[1])["token"]
mostrar("7. KPIs (jefe de bodega)", pedir("GET", "/api/reportes/kpis", token=jf))
mostrar("8. Exportar CSV", pedir("GET", "/api/reportes/export.csv", token=jf))
srv.shutdown()
